// import java.util.Scanner;

public class ShapeTest {
    public static void main(String[] args) {

        // // Test Circle
        // Circle circle1 = new Circle(0, null, false);
        // Circle circle2 = new Circle(3, "red", true);
        // System.out.println(circle1);
        // System.out.println(circle2);
        // System.out.println();

        // // Test Rectangle
        // Rectangle rec1 = new Rectangle();
        // Rectangle rec2 = new Rectangle(3, 5);
        // Rectangle rec3 = new Rectangle(2.4, 4.8, "red", true);
        // System.out.println(rec1);
        // System.out.println(rec2);
        // System.out.println(rec3);
        // System.out.println();

        // //Test Square
        // Square square1 = new Square();
        // Square square2 = new Square(0);
        // Square square3 = new Square(4);
        // Square square4 = new Square(3.4, "blue", false);
        // System.out.println(square1);
        // System.out.println(square2);
        // System.out.println(square3);
        // System.out.println(square4);

        // // End testing

    }
}
 